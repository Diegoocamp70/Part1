

const StatisticLine = (props) => {
    return (
        <div>
          <p>{props}  <span>{props}</span></p> 
        </div>
    );
};

export default StatisticLine;